package com.dlegacy.calculator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class TxtFileRead {
    public String nameFile;
    public File fisier;

    public TxtFileRead(String nameFile){
        this.nameFile = nameFile;
        fisier = new File(nameFile);
        if(fisier.canRead()){
            System.out.println("Poate fi citit!");
        }
    }

    public void readShow() throws Exception{
        BufferedReader br = new BufferedReader(new FileReader(fisier));

        String start;
        while ((start = br.readLine()) != null)
            System.out.println(start);
    }
}

