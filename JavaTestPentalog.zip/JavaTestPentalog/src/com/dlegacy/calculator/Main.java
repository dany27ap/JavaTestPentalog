package com.dlegacy.calculator;

public class Main {

    public static void main(String[] args) {
        TxtFileRead file = new TxtFileRead("Pentalog.txt");
        try {
            file.readShow();
        }catch (Exception exp){
            System.out.println(exp.getMessage());
        }
    }
}
